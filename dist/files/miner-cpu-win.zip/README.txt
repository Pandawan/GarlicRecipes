Windows CPU mining tutorial can be found here https://pandawanfr.github.io/GarlicRecipes/mining-cpu.html#windows

CPUMiner-Multi by tpruvot https://github.com/tpruvot/cpuminer-multi