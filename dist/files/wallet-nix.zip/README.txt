Please download the binaries here https://garlicoin.io/downloads

Linux Wallet Tutorial can be found at https://pandawanfr.github.io/GarlicRecipes/wallet-nix

To Connect to the Network
	garlicoind -connect=52.89.91.13

To Get a new Wallet
	gerlicoin-cli getnewaddress

To Get Your Wallet Info:
	garlicoin-cli getwalletinfo
