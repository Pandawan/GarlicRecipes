The binaries (exe files) have been updated using the 1/12/18 patch. Make sure that you patch it if new updates were released.

Windows Wallet Tutorial can be found at https://pandawanfr.github.io/GarlicoinHelp/wallet-win

To Connect to the Network
	garlicoind

To Get a Gew Wallet
	garlicoind getnewaddress

To Get Your Wallet Info:
	garlicoin-cli getwalletinfo